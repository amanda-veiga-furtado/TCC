import Tasks from './Tasks'
import Settings from './Settings'
const Controllers = {
    Tasks: Object.assign(Tasks, Tasks),
Settings: Object.assign(Settings, Settings),
}

export default Controllers