import TaskController from './TaskController'
const Tasks = {
    TaskController: Object.assign(TaskController, TaskController),
}

export default Tasks